# Components
This folder contains reusable UI components.

### Example Components to Add:
- **Timer.js** → Tracks time for a planet or moon.
- **Navbar.js** → A navigation bar for the app.
- **StatsCard.js** → Displays key stats for time tracking.
