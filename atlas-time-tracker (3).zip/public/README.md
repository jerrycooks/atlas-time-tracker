# Public Folder
This folder contains static assets such as images, logos, and icons.

### What to Put Here:
- `favicon.ico` → The app’s favicon.
- Logos or branding assets.
- Any other static files needed in the frontend.
